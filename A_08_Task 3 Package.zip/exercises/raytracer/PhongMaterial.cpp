#include "PhongMaterial.hpp"
#include "Light.hpp"
#include "Math.hpp"
#include "Ray.hpp"

namespace rt
{

PhongMaterial::PhongMaterial(const Vec3d& color, double reflectance, double shininess) :  
  Material(color,reflectance), mShininess(shininess)
{

}

Vec4d PhongMaterial::shade(const RayIntersection& intersection,
  const Light& light) const 
{
  // get normal and light direction
  Vec3d N = intersection.normal();
  Vec3d L = (light.position() - intersection.position()).normalize();

  double cosNL = std::max(dot(N,L),double(0));

  // Programming TASK 3: Extend this method.
  // This method currently implements a Lambert's material with ideal
  // diffuse reflection.
  // Your task is to implement a Phong, or a Blinn-Phong shading model.

  return Vec4d(this->color()*cosNL, 1.0);

}

} //namespace rt
